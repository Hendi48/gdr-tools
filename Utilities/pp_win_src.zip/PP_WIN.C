/*
 * Reads or writes a single byte from/to
 * anywhere within the address space of
 * the MN103 microcontroller inside of
 * the Hitachi-LG Xbox360 drive.
 *
 * author: Kevin East (SeventhSon)
 * email: kev@kev.nu
 * web: http://www.kev.nu/360/
 * date: 15th March 2006
 * platform: windows 2000/XP
 *
 */

#include <windows.h>
#include <ntddscsi.h>
#include <stdio.h>
#include <string.h>

#define USAGE "usage: pp_win drive_letter_or_device_number address_in_hex peek\n       pp_win drive_letter_or_device_number address_in_hex poke value_in_hex\n\n"
#define MODE_PEEK 0
#define MODE_POKE 1

/*
mov 0x000000??,D1
movbu D1,(0x????????)
rets
*/
unsigned char code[] = {0xFC,0xCD,0x00,0x00,0x00,0x00,0xFC,0x86,0x00,0x00,0x00,0x00,0xF0,0xFC};

int hex_atoi(void *dest, char *src, int dest_len)
{
	int src_last, i, j;
	unsigned char val;

	memset(dest, 0, dest_len);

	src_last = strlen(src) - 1;

	for(i = src_last; i >= 0; i--) {
		if(src[i] >= '0' && src[i] <= '9')
			val = src[i] - 0x30;
		else if(src[i] >= 'a' && src[i] <= 'f')
			val = (src[i] - 0x60) + 9;
		else if(src[i] >= 'A' && src[i] <= 'F')
			val = (src[i] - 0x40) + 9;
		else
			return 1; // invalid hex digit

		j = src_last - i;

		if(j & 1)
			val <<= 4;

		j >>= 1;

		if(j >= dest_len || j < 0)
			break;

		((unsigned char *)dest)[j] |= val;
	}
	
	return 0;
}

int main(int argc, char *argv[])
{
	HANDLE fd;
	char dev[40];
	SCSI_PASS_THROUGH_DIRECT *sptd;
	unsigned char sptd_sense[sizeof(*sptd) + 18], *sense, val[2], param_list[8];
	DWORD bytes;
	unsigned int addr, mode, i;

	sptd = (SCSI_PASS_THROUGH_DIRECT *)sptd_sense;
	sense = &sptd_sense[sizeof(*sptd)];	

	if(argc < 4) {
		printf(USAGE);
		return 1;
	}

	if(hex_atoi(&addr, argv[2], sizeof(addr))) {
		printf("error: invalid address %s\n", argv[2]);
		printf(USAGE);
		return 1;
	}

	if(!strcmp(argv[3], "peek")) {
		mode = MODE_PEEK;
		val[0] = 0;
	}
	else if(!strcmp(argv[3], "poke")) {
		if(argc < 5) {
			printf(USAGE);
			return 1;
		}
		mode = MODE_POKE;
		if(hex_atoi(&val[0], argv[4], sizeof(val[0]))) {
			printf("error: invalid poke value %s\n", argv[4]);
			printf(USAGE);
			return 1;
		}
	}
	else {
		printf("error: invalid mode %s\n", argv[3]);
		printf(USAGE);
		return 1;
	}

	if((argv[1][0] >= 'a' && argv[1][0] <= 'z') || (argv[1][0] >= 'A' && argv[1][0] <= 'Z'))
		sprintf(dev, "\\\\.\\%c:", argv[1][0]);
	else
		sprintf(dev, "\\\\.\\PhysicalDrive%u", atoi(argv[1]));


	if((fd = CreateFile(dev, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL)) == INVALID_HANDLE_VALUE) {
		printf("CreateFile() failed %d\n", GetLastError());
		return 1;
	}
	
	if(mode == MODE_PEEK) {
		// Hitachi read memory command
		memset(sptd, 0, sizeof(sptd_sense));
		sptd->Cdb[0] = 0x12;
		sptd->Cdb[4] = 36;
		sptd->Cdb[0] = 0xE7;
		sptd->Cdb[1] = 0x48;
		sptd->Cdb[2] = 0x49;
		sptd->Cdb[3] = 0x54;
		sptd->Cdb[4] = 0x01;
		sptd->Cdb[6] = (unsigned char)((addr & 0xFF000000) >> 24); // address MSB
		sptd->Cdb[7] = (unsigned char)((addr & 0x00FF0000) >> 16); // address
		sptd->Cdb[8] = (unsigned char)((addr & 0x0000FF00) >> 8); // address
		sptd->Cdb[9] = (unsigned char)(addr & 0x000000FF); // address LSB
		sptd->Cdb[11] = 1; // length LSB

		sptd->Length = sizeof(SCSI_PASS_THROUGH);
		sptd->CdbLength = 12;
		sptd->SenseInfoLength = 18;
		sptd->DataIn = SCSI_IOCTL_DATA_IN;
		sptd->DataTransferLength = 2; // quick hack: for some reason windows hates DataTransferLength = 1, so we have to read 2 and ignore the second.
		sptd->TimeOutValue = 15;
		sptd->DataBuffer = &val[0];
		sptd->SenseInfoOffset = sizeof(*sptd);

		if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL)) {
			printf("DeviceIOControl() failed %d\n", GetLastError());
			printf("Hitachi read memory command failed (sense: %02X/%02X/%02X)\n", sense[2] & 0x0F, sense[12], sense[13]);
		}
		else
			printf("0x%02X\n", val[0]);
	}
	else { // mode == MODE_POKE
		// initiate modeB
		memset(sptd, 0, sizeof(sptd_sense));
		sptd->Cdb[0] = 0xE7;
		sptd->Cdb[1] = 0x48;
		sptd->Cdb[2] = 0x49;
		sptd->Cdb[3] = 0x54;
		sptd->Cdb[4] = 0x30;
		sptd->Cdb[5] = 0x90;
		sptd->Cdb[6] = 0x90;
		sptd->Cdb[7] = 0xD0;
		sptd->Cdb[8] = 0x01;

		sptd->Length = sizeof(SCSI_PASS_THROUGH);
		sptd->CdbLength = 12;
		sptd->SenseInfoLength = 18;
		sptd->DataIn = SCSI_IOCTL_DATA_UNSPECIFIED;
		sptd->TimeOutValue = 15;
		sptd->SenseInfoOffset = sizeof(*sptd);
		
		if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL)) {
			printf("DeviceIOControl() failed %d\n", GetLastError());
			printf("failed to initiate modeB (sense: %02X/%02X/%02X)\n", sense[2] & 0x0F, sense[12], sense[13]);
		}
		else {
			*((unsigned int *)&code[8]) = addr;
			*((unsigned int *)&code[2]) = val[0];

			// upload code a byte at a time using RAM poke command
			for(i = 0; i < sizeof(code); i++) {
				// Hitachi poke RAM command
				memset(sptd, 0, sizeof(sptd_sense));
				sptd->Cdb[0] = 0xE7;
				sptd->Cdb[1] = 0x48;
				sptd->Cdb[2] = 0x49;
				sptd->Cdb[3] = 0x54;
				sptd->Cdb[4] = 0xCC;
				sptd->Cdb[5] = code[i];
				sptd->Cdb[8] = (unsigned char)(((0x80000000 + i) & 0xFF000000) >> 24); // address MSB
				sptd->Cdb[9] = (unsigned char)(((0x80000000 + i) & 0x00FF0000) >> 16); // address
				sptd->Cdb[10] = (unsigned char)(((0x80000000 + i) & 0x0000FF00) >> 8); // address
				sptd->Cdb[11] = (unsigned char)((0x80000000 + i) & 0x000000FF); // address LSB

				sptd->Length = sizeof(SCSI_PASS_THROUGH);
				sptd->CdbLength = 12;
				sptd->SenseInfoLength = 18;
				sptd->DataIn = SCSI_IOCTL_DATA_UNSPECIFIED;
				sptd->TimeOutValue = 15;
				sptd->SenseInfoOffset = sizeof(*sptd);

				if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL)) {
					printf("DeviceIOControl() failed %d\n", GetLastError());
					printf("Hitachi poke RAM command failed on byte %u (sense: %02X/%02X/%02X)\n", i, sense[2] & 0x0F, sense[12], sense[13]);
					CloseHandle(fd);
					return 1;
				}
			}

			// set (59E) bit 3 via Mode Select(10)
			memset(sptd, 0, sizeof(sptd_sense));
			sptd->Cdb[0] = 0x55;
			sptd->Cdb[1] = 0x10;
			sptd->Cdb[8] = 0x08;

			memset(param_list, 0, sizeof(param_list));
			param_list[1] = 6;

			sptd->Length = sizeof(SCSI_PASS_THROUGH);
			sptd->CdbLength = 12;
			sptd->SenseInfoLength = 18;
			sptd->DataIn = SCSI_IOCTL_DATA_OUT;
			sptd->DataTransferLength = 8;
			sptd->TimeOutValue = 15;
			sptd->DataBuffer = param_list;
			sptd->SenseInfoOffset = sizeof(*sptd);

			if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL)) {
				printf("DeviceIOControl() failed %d\n", GetLastError());
				printf("set (59E) bit 3 via Mode Select(10) failed (sense: %02X/%02X/%02X)\n", sense[2] & 0x0F, sense[12], sense[13]);
			}
			else {
				// jump to RAM routine via Mode Select(10)
				memset(sptd, 0, sizeof(sptd_sense));
				sptd->Cdb[0] = 0x55;
				sptd->Cdb[1] = 0x10;
				sptd->Cdb[3] = 0x48; // 'H'
				sptd->Cdb[4] = 0x4C; // 'L'
				sptd->Cdb[8] = 0x08;

				memset(param_list, 0, sizeof(param_list));
				param_list[1] = 6;
				
				sptd->Length = sizeof(SCSI_PASS_THROUGH);
				sptd->CdbLength = 12;
				sptd->SenseInfoLength = 18;
				sptd->DataIn = SCSI_IOCTL_DATA_OUT;
				sptd->DataTransferLength = 8;
				sptd->TimeOutValue = 15;
				sptd->DataBuffer = param_list;
				sptd->SenseInfoOffset = sizeof(*sptd);
				
				if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL))
					printf("done\n");
				else
//					printf("this shouldn't happen\n");
					printf("done\n"); // quick hack: in windows DeviceIoControl() doesn't fail here as it does in Linux. I can't think why this would be the case. The poke still works, so I just report done.
			}
		}
	}

	CloseHandle(fd);

	printf("\n");

	return 0;
}
