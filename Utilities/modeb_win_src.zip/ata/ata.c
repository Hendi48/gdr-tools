/*
 * Author: Kevin East (http://ww.kev.nu)
 * Description: Userspace ATA driver (Win32 version)
 *
 * Notes: This Win32 version requires Geek Hideout's userspace
 *        I/O library (http://www.geekhideout.com/iodll.shtml).
 */

#include "ata.h"

char *ata_errstr[] = {
/* ATA_ERR_CMD_ERR */"ATA command error",
/* ATA_ERR_PACKET_WRITE */"incomplete packet write",
/* ATA_ERR_TIMEOUT */"timed out while polling device state"
};

void ata_int_disable(struct ata_info *ai)
{
	PortOut(ai->reg.devc, ATA_DEVC_NIEN);
}

void ata_int_enable(struct ata_info *ai)
{
	PortOut(ai->reg.devc, 0x00);
}

int ata_wait(uint8 *byte, uint16 reg, uint8 mask, uint8 set, struct ata_info *ai)
{
	uint8 b;
	uint32 stime;

	stime = (uint32)timeGetTime();

	while(((b = PortIn(reg)) & mask) != set) {
		if(((uint32)timeGetTime() - stime) >= ai->timeout) {
			if(byte)
				*byte = b;
			ai->err.code = ATA_ERR_TIMEOUT;
			return 1;
		}
	}

	if(byte)
		*byte = b;

	return 0;
}

int ata_send_cmd(uint8 cmd, uint8 drive, struct ata_param *ap_in, struct ata_param *ap_out, uint8 drdy, struct ata_info *ai)
{
	if(ata_wait(NULL, ai->reg.alts, (uint8)(ATA_STAT_BSY | ATA_STAT_DRQ | drdy), drdy, ai)) // wait for bsy = 0, drq = 0 (and drdy = 1, if the drdy arg is set to ATA_WAIT_DRDY)
		return 1;
	
	if(ap_in && (ap_in->param & ATA_PARAM_DEV)) { // user has supplied additional device register contents
		if(ap_in->param & ATA_PARAM_ADDR48)
			PortOut(ai->reg.dev, (uint8)(ap_in->dev >> 8));
		if(drive == ATA_MASTER)
			PortOut(ai->reg.dev, (uint8)(ap_in->dev & (~ATA_DEV_DEV)));
		else if(drive == ATA_SLAVE)
			PortOut(ai->reg.dev, (uint8)(ap_in->dev | ATA_DEV_DEV));
		else // drive == ATA_NO_DRIVE
			PortOut(ai->reg.dev, (uint8)ap_in->dev);
		if(ata_wait(NULL, ai->reg.alts, (uint8)(ATA_STAT_BSY | ATA_STAT_DRQ | drdy), drdy, ai))
			return 1;
	}
	else if(drive != ATA_NO_DRIVE && (PortIn(ai->reg.dev) & ATA_DEV_DEV) != drive) { // incorrect device currently selected
		if(ap_in && (ap_in->param & ATA_PARAM_ADDR48))
			PortOut(ai->reg.dev, 0x00);
		PortOut(ai->reg.dev, drive);
		if(ata_wait(NULL, ai->reg.alts, (uint8)(ATA_STAT_BSY | ATA_STAT_DRQ | drdy), drdy, ai))
			return 1;
	}

	if(ap_in) {
		if(ap_in->param & ATA_PARAM_FEAT) {
			if(ap_in->param & ATA_PARAM_ADDR48)
				PortOut(ai->reg.feat, (uint8)(ap_in->feat >> 8));
			PortOut(ai->reg.feat, (uint8)ap_in->feat);
		}
		if(ap_in->param & ATA_PARAM_LBAH) {
			if(ap_in->param & ATA_PARAM_ADDR48)
				PortOut(ai->reg.lbah, (uint8)(ap_in->lbah >> 8));
			PortOut(ai->reg.lbah, (uint8)ap_in->lbah);
		}
		if(ap_in->param & ATA_PARAM_LBAM) {
			if(ap_in->param & ATA_PARAM_ADDR48)
				PortOut(ai->reg.lbam, (uint8)(ap_in->lbam >> 8));
			PortOut(ai->reg.lbam, (uint8)ap_in->lbam);
		}
		if(ap_in->param & ATA_PARAM_LBAL) {
			if(ap_in->param & ATA_PARAM_ADDR48)
				PortOut(ai->reg.lbal, (uint8)(ap_in->lbal >> 8));
			PortOut(ai->reg.lbal, (uint8)ap_in->lbal);
		}
		if(ap_in->param & ATA_PARAM_SECC) {
			if(ap_in->param & ATA_PARAM_ADDR48)
				PortOut(ai->reg.secc, (uint8)(ap_in->secc >> 8));
			PortOut(ai->reg.secc, (uint8)ap_in->secc);
		}
	}
	PortOut(ai->reg.comm, cmd);
	
	if(cmd != ATA_CMD_EXECUTE_DEVICE_DIAGNOSTIC)
		Sleep(1); // we only need to wait for at least 400ns but the windows API doesn't seem to offer anything less than a 1ms delay
	else
		Sleep(2);
		
	if(ata_wait(&ai->err.alts, ai->reg.alts, ATA_STAT_BSY, 0, ai)) // wait for bsy = 0
		return 1;
	if(ai->err.alts & (ATA_STAT_ERR | ATA_STAT_DF)) {
		ai->err.err = PortIn(ai->reg.err);
		if(cmd == ATA_CMD_IDENTIFY_DEVICE || cmd == ATA_CMD_READ_SECTORS) {
			// device signature
//			ai->sig.dev = PortIn(ai->reg.dev); // (see struct ata_sig in the header file)
			ai->sig.lbah = PortIn(ai->reg.lbah);
			ai->sig.lbam = PortIn(ai->reg.lbam);
			ai->sig.lbal = PortIn(ai->reg.lbal);
			ai->sig.secc = PortIn(ai->reg.secc);
		}
		ai->err.code = ATA_ERR_CMD_ERR;
		return 1; // error or device fault
	}

	if(cmd == ATA_CMD_EXECUTE_DEVICE_DIAGNOSTIC || cmd == ATA_CMD_DEVICE_RESET) {
		ai->err.err = PortIn(ai->reg.err); // diagnostic code
		// device signature
//		ai->sig.dev = PortIn(ai->reg.dev); // (see struct ata_sig in the header file)
		ai->sig.lbah = PortIn(ai->reg.lbah);
		ai->sig.lbam = PortIn(ai->reg.lbam);
		ai->sig.lbal = PortIn(ai->reg.lbal);
		ai->sig.secc = PortIn(ai->reg.secc);
	}

	if(ap_out) {
		PortOut(ai->reg.devc, 0x00); // clear High Order Bit
		if(ap_out->param & ATA_PARAM_DEV)
			ap_out->dev = (uint8)PortIn(ai->reg.dev);
		if(ap_out->param & ATA_PARAM_FEAT)
			ap_out->feat = (uint8)PortIn(ai->reg.feat);
		if(ap_out->param & ATA_PARAM_LBAH)
			ap_out->lbah = (uint8)PortIn(ai->reg.lbah);
		if(ap_out->param & ATA_PARAM_LBAM)
			ap_out->lbam = (uint8)PortIn(ai->reg.lbam);
		if(ap_out->param & ATA_PARAM_LBAL)
			ap_out->lbal = (uint8)PortIn(ai->reg.lbal);
		if(ap_out->param & ATA_PARAM_SECC)
			ap_out->secc = (uint8)PortIn(ai->reg.secc);

		// read previous register contents for commands using 48-bit addressing
		if(ap_out->param & ATA_PARAM_ADDR48) {
			PortOut(ai->reg.devc, (uint8)ATA_DEVC_HOB); // set High Order Bit
			if(ap_out->param & ATA_PARAM_DEV)
				ap_out->dev |= PortIn(ai->reg.dev) << 8;
			if(ap_out->param & ATA_PARAM_FEAT)
				ap_out->feat |= PortIn(ai->reg.feat) << 8;
			if(ap_out->param & ATA_PARAM_LBAH)
				ap_out->lbah |= PortIn(ai->reg.lbah) << 8;
			if(ap_out->param & ATA_PARAM_LBAM)
				ap_out->lbam |= PortIn(ai->reg.lbam) << 8;
			if(ap_out->param & ATA_PARAM_LBAL)
				ap_out->lbal |= PortIn(ai->reg.lbal) << 8;
			if(ap_out->param & ATA_PARAM_SECC)
				ap_out->secc |= PortIn(ai->reg.secc) << 8;
		}
	}

	return 0;
}

int ata_read_pio(void *data, uint32 *bytes, uint32 len, uint32 blk_len, struct ata_info *ai)
{
	uint8 packet;
	uint32 i, blk_len_;

	*bytes = 0;

	if(blk_len == ATA_PACKET_BLK)
		packet = 1;
	else
		packet = 0;

	for(;;) {
		if(ata_wait(&ai->err.alts, ai->reg.alts, ATA_STAT_BSY, 0, ai)) // wait for bsy = 0
			return 1;
		if(!(ai->err.alts & ATA_STAT_DRQ)) { // device ended transfer
			if(ai->err.alts & (ATA_STAT_ERR | ATA_STAT_DF)) {
				ai->err.err = PortIn(ai->reg.err);
				ai->err.code = ATA_ERR_CMD_ERR;
				return 1; // error or device fault
			}
			return 0;
		}
		if(packet) // packet transfer, so read DRQ block size from the byte count registers
			blk_len = (PortIn(ai->reg.lbah) << 8) | PortIn(ai->reg.lbam);
		if((len - *bytes) < blk_len) // partial last block
			blk_len = len - *bytes;
		if(ai->pio_mode == ATA_PIO_32) {
			blk_len_ = blk_len >> 2;
			for(i = 0; i < blk_len_; i++) // 32-bit PIO transfers
				((uint32 *)data)[i] = PortDWordIn(ai->reg.data);
		}
		else if(ai->pio_mode == ATA_PIO_16) {
			blk_len_ = blk_len >> 1;
			for(i = 0; i < blk_len_; i++) // 16-bit PIO transfers
				((uint16 *)data)[i] = PortWordIn(ai->reg.data);
		}
		else { // ai->pio_mode == ATA_PIO_8
			for(i = 0; i < blk_len_; i++) // 8-bit PIO transfers
				((uint8 *)data)[i] = PortIn(ai->reg.data);
		}
		if(ai->pio_mode == ATA_PIO_32) {
			if(blk_len_ = blk_len & 0x03) {
				if(blk_len_ > 1) {
					*((uint16 *)&((uint32 *)data)[i]) = PortWordIn(ai->reg.data);
					if(blk_len_ > 2)
						*((uint8 *)&((uint32 *)data)[i] + sizeof(uint32)) = PortIn(ai->reg.data);
				}
				else
					*((uint8 *)&((uint32 *)data)[i]) = PortIn(ai->reg.data);
			}
		}
		else if(ai->pio_mode == ATA_PIO_16) {
			if(blk_len_ = blk_len & 0x01)
				*((uint8 *)&((uint16 *)data)[i]) = PortIn(ai->reg.data);
		}
		if((*bytes += blk_len) >= len) // done
			return 0;
		data = (uint8 *)data + blk_len;
		PortIn(ai->reg.alts); // wait for one PIO transfer cycle
	}

	return 0; // never executed
}

int ata_write_pio(void *data, uint32 *bytes, uint32 len, uint32 blk_len, struct ata_info *ai)
{
	uint8 packet;
	uint32 i, blk_len_;

	*bytes = 0;

	if(blk_len == ATA_PACKET_BLK)
		packet = 1;
	else
		packet = 0;

	for(;;) {
		if(ata_wait(&ai->err.alts, ai->reg.alts, ATA_STAT_BSY, 0, ai)) // wait for bsy = 0
			return 1;
		if(!(ai->err.alts & ATA_STAT_DRQ)) { // device ended transfer
			if(ai->err.alts & (ATA_STAT_ERR | ATA_STAT_DF)) {
				ai->err.err = PortIn(ai->reg.err);
				ai->err.code = ATA_ERR_CMD_ERR;
				return 1; // error or device fault
			}
			return 0;
		}
		if(packet) // packet transfer, so read DRQ block size from the byte count registers
			blk_len = (PortIn(ai->reg.lbah) << 8) | PortIn(ai->reg.lbam);
		if((len - *bytes) < blk_len) // partial last block
			blk_len = len - *bytes;
		if(ai->pio_mode == ATA_PIO_32) {
			blk_len_ = blk_len >> 2;
			for(i = 0; i < blk_len_; i++) // 32-bit PIO transfers
				PortDWordOut(ai->reg.data, ((uint32 *)data)[i]);
		}
		else if(ai->pio_mode == ATA_PIO_16) {
			blk_len_ = blk_len >> 1;
			for(i = 0; i < blk_len_; i++) // 16-bit PIO transfers
				PortWordOut(ai->reg.data, ((uint16 *)data)[i]);
		}
		else { // ai->pio_mode == ATA_PIO_8
			for(i = 0; i < blk_len_; i++) // 8-bit PIO transfers
				PortOut(ai->reg.data, ((uint8 *)data)[i]);
		}
		if(ai->pio_mode == ATA_PIO_32) {
			if(blk_len_ = blk_len & 0x03) {
				if(blk_len_ > 1) {
					PortWordOut(ai->reg.data, *((uint16 *)&((uint32 *)data)[i]));
					if(blk_len_ > 2)
						PortOut(ai->reg.data, *((uint8 *)&((uint32 *)data)[i] + sizeof(uint32)));
				}
				else
					PortOut(ai->reg.data, *((uint8 *)&((uint32 *)data)[i]));
			}
		}
		else if(ai->pio_mode == ATA_PIO_16) {
			if(blk_len_ = blk_len & 0x01)
				PortOut(ai->reg.data, *((uint8 *)&((uint16 *)data)[i]));
		}
		if((*bytes += blk_len) >= len) // done
			return 0;
		data = (uint8 *)data + blk_len;
		PortIn(ai->reg.alts); // wait for one PIO transfer cycle
	}

	return 0; // never executed
}

int ata_cmd(uint8 cmd, uint8 drive, struct ata_param *ap_in, struct ata_param *ap_out, uint8 drdy, uint8 intr, struct ata_info *ai)
{
	int ret;
	
	if(intr == ATA_INTR_OFF)
		ata_int_disable(ai);
	ret = ata_send_cmd(cmd, drive, ap_in, ap_out, drdy, ai);
	if(intr == ATA_INTR_OFF)
		ata_int_enable(ai);

	return ret;
}

int ata_cmd_in(uint8 cmd, uint8 drive, struct ata_param *ap_in, struct ata_param *ap_out, uint8 drdy, void *data, uint32 *bytes, uint32 len, uint32 blk_len, uint8 intr, struct ata_info *ai)
{
	int ret;

	if(intr == ATA_INTR_OFF)
		ata_int_disable(ai);
	if(!(ret = ata_send_cmd(cmd, drive, ap_in, ap_out, drdy, ai)))
		ret = ata_read_pio(data, bytes, len, blk_len, ai);
	if(intr == ATA_INTR_OFF)
		ata_int_enable(ai);

	return ret;
}

int ata_cmd_out(uint8 cmd, uint8 drive, struct ata_param *ap_in, struct ata_param *ap_out, uint8 drdy, void *data, uint32 *bytes, uint32 len, uint32 blk_len, uint8 intr, struct ata_info *ai)
{
	int ret;
	
	if(intr == ATA_INTR_OFF)
		ata_int_disable(ai);
	if(!(ret = ata_send_cmd(cmd, drive, ap_in, ap_out, drdy, ai)))
		ret = ata_write_pio(data, bytes, len, blk_len, ai);
	if(intr == ATA_INTR_OFF)
		ata_int_enable(ai);

	return ret;
}

int ata_send_packet(uint8 *packet, uint32 packet_len, uint8 drive, uint16 blk_max, struct ata_info *ai)
{
	struct ata_param ap;
	uint32 bytes;

	ap.param = ATA_PARAM_FEAT | ATA_PARAM_SECC;
	ap.feat = 0;
	ap.secc = 0;
	if(blk_max != ATA_NO_BLK) {
		ap.param |= ATA_PARAM_BC;
		ap.lbam = blk_max & 0xFF;
		ap.lbah = blk_max >> 8;
	}

	if(ata_send_cmd(ATA_CMD_PACKET, drive, (struct ata_param *)&ap, NULL, ATA_NO_DRDY, ai)) {
		ai->err.code = ATA_ERR_CMD_ERR;
		return 1; // error or df
	}

	if(ata_write_pio(packet, &bytes, packet_len, ATA_DEFAULT_BLK, ai)) {
		ai->err.code = ATA_ERR_CMD_ERR;
		return 1; // error or df
	}
	
	if(bytes != packet_len) {
		ai->err.code = ATA_ERR_PACKET_WRITE;
		return 1; // entire packet not written
	}
	
	PortIn(ai->reg.alts); // wait for one PIO transfer cycle
	
	if(ata_wait(&ai->err.alts, ai->reg.alts, ATA_STAT_BSY, 0, ai)) // wait for bsy = 0
		return 1;
	if(ai->err.alts & (ATA_STAT_ERR | ATA_STAT_DF)) {
		ai->err.err = PortIn(ai->reg.err);
		ai->err.code = ATA_ERR_CMD_ERR;
		return 1; // error or df
	}

	return 0;
}

int ata_packet(uint8 *packet, uint32 packet_len, uint8 drive, uint8 intr, struct ata_info *ai)
{
	int ret;

	if(intr == ATA_INTR_OFF)
		ata_int_disable(ai);
	ret = ata_send_packet(packet, packet_len, drive, ATA_NO_BLK, ai);
	if(intr == ATA_INTR_OFF)
		ata_int_enable(ai);

	return ret;
}

int ata_packet_in(uint8 *packet, uint32 packet_len, uint8 drive, uint16 blk_max, void *data, uint32 *bytes, uint32 len, uint8 intr, struct ata_info *ai)
{
	int ret;

	if(intr == ATA_INTR_OFF)
		ata_int_disable(ai);
	if(!(ret = ata_send_packet(packet, packet_len, drive, blk_max, ai)))
		ret = ata_read_pio(data, bytes, len, ATA_PACKET_BLK, ai);
	if(intr == ATA_INTR_OFF)
		ata_int_enable(ai);

	return ret;
}

int ata_packet_out(uint8 *packet, uint32 packet_len, uint8 drive, uint16 blk_max, void *data, uint32 *bytes, uint32 len, uint8 intr, struct ata_info *ai)
{
	int ret;

	if(intr == ATA_INTR_OFF)
		ata_int_disable(ai);
	if(!(ret = ata_send_packet(packet, packet_len, drive, blk_max, ai)))
		ret = ata_write_pio(data, bytes, len, ATA_PACKET_BLK, ai);
	if(intr == ATA_INTR_OFF)
		ata_int_enable(ai);

	return ret;
}

void ata_dump_errstr(FILE *out, int code)
{
	fprintf(out, ata_errstr[code]);
}

void ata_dump_err(FILE *out, struct ata_err *ae)
{
	uint8 i;

	if(ae->code != ATA_ERR_CMD_ERR) {
		ata_dump_errstr(out, ae->code);
		fprintf(out, "\n");
	}
	else {
		if(!(ae->alts & ATA_STAT_DF) && !(ae->alts & ATA_STAT_ERR))
			fprintf(out, "no error\n");
		else {
			if(ae->alts & ATA_STAT_DF)
				fprintf(out, "a device fault occured\n");
			if((ae->alts & ATA_STAT_ERR) || (ae->alts & ATA_STAT_DF)) {
				if(ae->err & ATA_ERR_ABRT)
					fprintf(out, "the device aborted the command\n");
				fprintf(out, "error register: 0x%02X (MSB ", ae->err);
				for(i = 0; i < 8; i++) {
					if(!(ae->err & (0x80 >> i)))
						fprintf(out, "0");
					else
						fprintf(out, "1");
				}
				fprintf(out, " LSB)\n");
			}
		}
	}
}

void ata_init_reg(struct ata_reg *ar, uint16 comm_base, uint16 ctrl_base)
{
	ar->alts = ctrl_base + ATA_ALTS_OFF;
	ar->devc = ctrl_base + ATA_DEVC_OFF;
	ar->comm = comm_base + ATA_COMM_OFF;
	ar->data = comm_base + ATA_DATA_OFF;
	ar->dev = comm_base + ATA_DEV_OFF;
	ar->err = comm_base + ATA_ERR_OFF;
	ar->feat = comm_base + ATA_FEAT_OFF;
	ar->lbah = comm_base + ATA_LBAH_OFF;
	ar->lbal = comm_base + ATA_LBAL_OFF;
	ar->lbam = comm_base + ATA_LBAM_OFF;
	ar->secc = comm_base + ATA_SECC_OFF;
	ar->stat = comm_base + ATA_STAT_OFF;
}

void ata_init_info(struct ata_info *ai, uint16 comm_base, uint16 ctrl_base, uint8 pio_mode, uint32 timeout)
{
	ata_init_reg(&ai->reg, comm_base, ctrl_base);
	ai->pio_mode = pio_mode;
	memset(&ai->err, 0, sizeof(ai->err));
	memset(&ai->sig, 0, sizeof(ai->sig));
	ai->timeout = timeout;
}

int ata_soft_reset(struct ata_info *ai)
{
	PortOut(ai->reg.devc, ATA_DEVC_SRST); // set SRST
	Sleep(1); // we only need to wait for at least 5us but the windows API doesn't seem to offer anything less than a 1ms delay
	PortOut(ai->reg.devc, 0x00); // clear SRST
	Sleep(2);
	if(ata_wait(NULL, ai->reg.alts, ATA_STAT_BSY, 0, ai))
		return 1;
	// device signature
//	ai->sig.dev = PortIn(ai->reg.dev); // (see struct ata_sig in the header file)
	ai->sig.lbah = PortIn(ai->reg.lbah);
	ai->sig.lbam = PortIn(ai->reg.lbam);
	ai->sig.lbal = PortIn(ai->reg.lbal);
	ai->sig.secc = PortIn(ai->reg.secc);

	return 0;
}
