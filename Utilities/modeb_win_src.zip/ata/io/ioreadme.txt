IO.DLL (c) 1995-2003 Fred Bulback

The documentation for IO.DLL can be found at:

http://www.geekhideout.com/iodll.shtml
