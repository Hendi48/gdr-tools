#include <windows.h> // *shudder* (for Sleep() and timeGetTime()) timeGetTime() also requires Winmm.lib.
#include <stdio.h> // for fprintf() and FILE struct
#include <string.h> // for memset()
#include "io/io.h" // #include "io/io.h" // Geek Hideout's userspace I/O library

// register offsets
// Command block
#define ATA_DATA_OFF 0 // data (read/write)
#define ATA_ERR_OFF 1 // error (read)
#define ATA_FEAT_OFF 1 // features (write)
#define ATA_SECC_OFF 2 // sector count (read/write for non-packet devices, write for packet devices)
#define ATA_LBAL_OFF 3 // LBA low (read/write)
#define ATA_LBAM_OFF 4 // LBA mid (read/write)
#define ATA_LBAH_OFF 5 // LBA high (read/write)
#define ATA_DEV_OFF 6 // device (read/write)
#define ATA_STAT_OFF 7 // status (read)
#define ATA_COMM_OFF 7 // command (write)
// Control block
#define ATA_ALTS_OFF 0 // alternate status (read)
#define ATA_DEVC_OFF 0 // device control (write)

// status register bits
#define ATA_STAT_BSY 0x80 // device busy
#define ATA_STAT_DRDY 0x40 // device ready
#define ATA_STAT_DF 0x20 // device fault
#define ATA_STAT_DRQ 0x08 // data request
#define ATA_STAT_ERR 0x01 // error

// device register bits
#define ATA_DEV_DEV 0x10 // device select
#define ATA_DEV_LBA 0x40 // LBA bit

// device control register bits
#define ATA_DEVC_NIEN 0x02
#define ATA_DEVC_SRST 0x04
#define ATA_DEVC_HOB 0x80

// error register bits
#define ATA_ERR_ABRT 0x04

// ATA command codes
// General feature set
#define ATA_CMD_EXECUTE_DEVICE_DIAGNOSTIC 0x90
#define ATA_CMD_FLUSH_CACHE 0xE7
#define ATA_CMD_IDENTIFY_DEVICE 0xEC
#define ATA_CMD_READ_DMA 0xC8
#define ATA_CMD_READ_MULTIPLE 0xC4
#define ATA_CMD_READ_SECTORS 0x20
#define ATA_CMD_READ_VERIFY_SECTORS 0x40
#define ATA_CMD_SET_FEATURES 0xEF
#define ATA_CMD_SET_MULTIPLE_MODE 0xC6
#define ATA_CMD_WRITE_DMA 0xCA
#define ATA_CMD_WRITE_MULTIPLE 0xC5
#define ATA_CMD_WRITE_SECTORS 0x30
#define ATA_CMD_DOWNLOAD_MICROCODE 0x92
#define ATA_CMD_NOP 0x00
#define ATA_CMD_READ_BUFFER 0xE4
#define ATA_CMD_WRITE_BUFFER 0xE8
// Packet feature set
#define ATA_CMD_PACKET 0xA0
#define ATA_CMD_DEVICE_RESET 0x08
#define ATA_CMD_IDENTIFY_PACKET_DEVICE 0xA1
// Power Management feature set
#define ATA_CMD_CHECK_POWER_MODE 0xE5
#define ATA_CMD_IDLE_IMMEDIATE 0xE1
#define ATA_CMD_SLEEP 0xE6
#define ATA_CMD_STANDBY 0xE2
#define ATA_CMD_STANDBY_IMMEDIATE 0xE0
// Security Mode feature set
#define ATA_CMD_SECURITY_SET_PASSWORD 0xF1
#define ATA_CMD_SECURITY_UNLOCK 0xF2
#define ATA_CMD_SECURITY_ERASE_PREPARE 0xF3
#define ATA_CMD_SECURITY_ERASE_UNIT 0xF4
#define ATA_CMD_SECURITY_FREEZE_LOCK 0xF5
#define ATA_CMD_SECURITY_DISABLE_PASSWORD 0xF6
// SMART feature set
#define ATA_CMD_SMART 0xB0
#define ATA_SUBCMD_SMART_DISABLE_OPERATIONS 0xD9
#define ATA_SUBCMD_SMART_ENABLE_DISABLE_AUTOSAVE 0xD2
#define ATA_SUBCMD_SMART_ENABLE_OPERATIONS 0xD8
#define ATA_SUBCMD_SMART_RETURN_STATUS 0xDA
#define ATA_SUBCMD_SMART_EXECUTE_OFFLINE_IMMEDIATE 0xD4
#define ATA_SUBCMD_SMART_READ_DATA 0xD0
#define ATA_SUBCMD_SMART_READ_LOG 0xD5
#define ATA_SUBCMD_SMART_WRITE_LOG 0xD6
// Host Protected Area feature set
#define ATA_CMD_READ_NATIVE_MAX_ADDRESS 0xF8
#define ATA_CMD_READ_NATIVE_MAX_ADDRESS_EXT 0x27
#define ATA_CMD_SET_MAX_ADDRESS_EXT 0x37
#define ATA_CMD_SET_MAX_ADDRESS 0xF9
#define ATA_SUBCMD_SET_MAX_SET_PASSWORD 0x01
#define ATA_SUBCMD_SET_MAX_LOCK 0x02
#define ATA_SUBCMD_SET_MAX_UNLOCK 0x03
#define ATA_SUBCMD_SET_MAX_FREEZE_LOCK 0x04
// Compact Falsh Association feature set
#define ATA_CMD_CFA_REQUEST_EXTENDED_ERROR_CODE 0x03
#define ATA_CMD_CFA_WRITE_SECTORS_WITHOUT_ERASE 0x38
#define ATA_CMD_CFA_WRITE_MULTIPLE_WITHOUT_ERASE 0xCD
#define ATA_CMD_CFA_TRANSLATE_SECTOR 0x87
// Removable Media Status Notification feature set
#define ATA_CMD_GET_MEDIA_STATUS 0xDA
// Removable Media feature set
#define ATA_CMD_MEDIA_EJECT 0xED
#define ATA_CMD_MEDIA_LOCK 0xDE
#define ATA_CMD_MEDIA_UNLOCK 0xDF
// 48-bit Address feature set
#define ATA_CMD_FLUSH_CACHE_EXT 0xEA
#define ATA_CMD_READ_DMA_EXT 0x25
#define ATA_CMD_READ_DMA_QUEUED_EXT 0x26
#define ATA_CMD_READ_MULTIPLE_EXT 0x29
#define ATA_CMD_READ_SECTORS_EXT 0x24
#define ATA_CMD_READ_VERIFY_SECTORS_EXT 0x42
#define ATA_CMD_WRITE_DMA_EXT 0x35
#define ATA_CMD_WRITE_DMA_FUA_EXT 0x3D
#define ATA_CMD_WRITE_DMA_QUEUED_EXT 0x36
#define ATA_CMD_WRITE_DMA_QUEUED_FUA_EXT 0x3E
#define ATA_CMD_WRITE_MULTIPLE_EXT 0x39
#define ATA_CMD_WRITE_MULTIPLE_FUA_EXT 0xCE
#define ATA_CMD_WRITE_SECTORS_EXT 0x34
// Device Configuration Overlay feature set
#define ATA_CMD_DEVICE_CONFIGURATION 0xB1
#define ATA_SUBCMD_DEVICE_CONFIGURATION_RESTORE 0xC0
#define ATA_SUBCMD_DEVICE_CONFIGURATION_FREEZE_LOCK 0xC1
#define ATA_SUBCMD_DEVICE_CONFIGURATION_IDENTIFY 0xC2
#define ATA_SUBCMD_DEVICE_CONFIGURATION_SET 0xC3
// Media Card Pass Through feature set
#define ATA_CMD_CHECK_MEDIA_CARD_TYPE 0xD1
// Streaming feature set
#define ATA_CMD_CONFIGURE_STREAM 0x51
#define ATA_CMD_READ_STREAM_EXT 0x2B
#define ATA_CMD_WRITE_STREAM_EXT 0x3B
#define ATA_CMD_READ_STREAM_DMA_EXT 0x2A
#define ATA_CMD_WRITE_STREAM_DMA_EXT 0x3A
// General Purpose Logging feature set
#define ATA_CMD_READ_LOG_EXT 0x2F
#define ATA_CMD_WRITE_LOG_EXT 0x3F

// Command parameter register select bits (see struct ata_param.param)
#define ATA_PARAM_NONE 0x00
#define ATA_PARAM_DEV 0x01
#define ATA_PARAM_FEAT 0x02
#define ATA_PARAM_LBAH 0x04
#define ATA_PARAM_LBAM 0x08
#define ATA_PARAM_LBAL 0x10
#define ATA_PARAM_LBA ATA_PARAM_LBAH | ATA_PARAM_LBAM | ATA_PARAM_LBAL // all LBA registers
#define ATA_PARAM_SECC 0x20
// packet devices
#define ATA_PARAM_BC ATA_PARAM_LBAM | ATA_PARAM_LBAH // both byte count registers
// 48-bit devices
#define ATA_PARAM_ADDR48 0x80 // use 48-bit addressing

// Function parameter definitons
#define ATA_WAIT_DRDY ATA_STAT_DRDY // drdy parameter for ata_send_cmd()
#define ATA_NO_DRDY 0x00

#define ATA_MASTER 0x00 // drive parameter for ata_send_cmd()
#define ATA_NO_DRIVE 0x01
#define ATA_SLAVE ATA_DEV_DEV

#define ATA_PACKET_BLK 0x00 // blk_len parameter for ata_read_pio() and ata_write_pio()
#define ATA_DEFAULT_BLK 512 // blk_len parameter for ata_read_pio() and ata_write_pio() (default size in bytes of each DRQ block)

#define ATA_PIO_32 0 // pio_mode parameter for ata_set_info()
#define ATA_PIO_16 1
#define ATA_PIO_8 2

#define ATA_NO_BLK 0x00 // blk_max parameter for ata_send_packet()

#define ATA_INTR_OFF 0x00 // intr parameter for ata_cmd(), ata_cmd_in(), ata_cmd_out(), ata_packet(), ata_packet_in() and ata_packet_out()
#define ATA_INTR_ON 0x01

#define ATA_NO_TIMEOUT 0 // timeout parameter for ata_init_info()
#define ATA_DEFAULT_TIMEOUT 10000 // in milliseconds

// Error codes
#define ATA_ERR_CMD_ERR 0
#define ATA_ERR_PACKET_WRITE 1
#define ATA_ERR_TIMEOUT 2

// Typedefs
typedef unsigned __int64 uint64;
typedef unsigned __int32 uint32;
typedef unsigned __int16 uint16;
typedef unsigned __int8 uint8;
typedef __int64 int64;
typedef __int32 int32;
typedef __int16 int16;
typedef __int8 int8;


// Types
struct ata_reg { // register I/O addresses
	uint16 data;
	uint16 err;
	uint16 feat;
	uint16 secc;
	uint16 lbal;
	uint16 lbam;
	uint16 lbah;
	uint16 dev;
	uint16 stat;
	uint16 comm;
	uint16 alts;
	uint16 devc;
};

struct ata_param { // Command parameter register contents (parameter to ata_send_cmd())
	uint8 param; // Bitmap indicating which registers are to be used as command parameters and whether to use 48-bit addressing
	uint16 dev;
	uint16 feat;
	uint16 lbah;
	uint16 lbam;
	uint16 lbal;
	uint16 secc;
};

struct ata_err { // Registers used for error reporting
	int code; // error code (see error code definitions above)
	uint8 alts; // contents of the alterate status register
	uint8 err; // contents of the error register
};

struct ata_sig { // Registers used for device signatures
	uint8 secc;
	uint8 lbah;
	uint8 lbam;
	uint8 lbal;
//	uint8 dev; // NOTE: a T13 erratum (http://www.t13.org/docs2005/e05108r2-ATA-ATAPI-7_Erratum.pdf) exists that removes the device register from the device signatures.
};

struct ata_info { // globally applicable information used as input and output to/from most of the functions in this library
	struct ata_reg reg; // [input] contains ATA register addresses
	uint8 pio_mode; // [input] selects, 8, 16 or 32 bit PIO transfers
	struct ata_err err; // [output] contains command error information after a failed command or a diagnostic code after a successful EXECUTE DEVICE DIAGNOSTIC or DEVICE RESET command.
	struct ata_sig sig; // [output] contains device signature after a software reset, successful EXECUTE DEVICE DIAGNOSTIC command, successful DEVICE RESET command, failed READ_SECTORS command or a failed IDENTIFY DEVICE command.
	uint32 timeout; // [input] timeout for device state polls (i.e. ata_wait() calls) in milliseconds.
};


// prototypes
void ata_int_disable(struct ata_info *ai);
void ata_int_enable(struct ata_info *ai);
int ata_wait(uint8 *byte, uint16 reg, uint8 mask, uint8 set, struct ata_info *ai);
int ata_send_cmd(uint8 cmd, uint8 drive, struct ata_param *ap_in, struct ata_param *ap_out, uint8 drdy, struct ata_info *ai);
int ata_read_pio(void *data, uint32 *bytes, uint32 len, uint32 blk_len, struct ata_info *ai);
int ata_write_pio(void *data, uint32 *bytes, uint32 len, uint32 blk_len, struct ata_info *ai);
int ata_cmd(uint8 cmd, uint8 drive, struct ata_param *ap_in, struct ata_param *ap_out, uint8 drdy, uint8 intr, struct ata_info *ai);
int ata_cmd_in(uint8 cmd, uint8 drive, struct ata_param *ap_in, struct ata_param *ap_out, uint8 drdy, void *data, uint32 *bytes, uint32 len, uint32 blk_len, uint8 intr, struct ata_info *ai);
int ata_cmd_out(uint8 cmd, uint8 drive, struct ata_param *ap_in, struct ata_param *ap_out, uint8 drdy, void *data, uint32 *bytes, uint32 len, uint32 blk_len, uint8 intr, struct ata_info *ai);
int ata_send_packet(uint8 *packet, uint32 packet_len, uint8 drive, uint16 blk_max, struct ata_info *ai);
int ata_packet(uint8 *packet, uint32 packet_len, uint8 drive, uint8 intr, struct ata_info *ai);
int ata_packet_in(uint8 *packet, uint32 packet_len, uint8 drive, uint16 blk_max, void *data, uint32 *bytes, uint32 len, uint8 intr, struct ata_info *ai);
int ata_packet_out(uint8 *packet, uint32 packet_len, uint8 drive, uint16 blk_max, void *data, uint32 *bytes, uint32 len, uint8 intr, struct ata_info *ai);
void ata_dump_errstr(FILE *out, int code);
void ata_dump_err(FILE *out, struct ata_err *ae);
void ata_init_reg(struct ata_reg *ar, uint16 comm_base, uint16 ctrl_base);
void ata_init_reg(struct ata_reg *ar, uint16 comm_base, uint16 ctrl_base);
void ata_init_info(struct ata_info *ai, uint16 comm_base, uint16 ctrl_base, uint8 pio_mode, uint32 timeout);
int ata_soft_reset(struct ata_info *ai);
