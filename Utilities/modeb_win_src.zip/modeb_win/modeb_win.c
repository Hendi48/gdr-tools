/*
 * Puts a Hitachi-LG Xbox 360 DVD drive into modeB.
 * In modeB, the drive responds to standard ATAPI
 * commands that it otherwise wouldn't (for example:
 * Read(12), Inquiry, Mode Sense(10)). ModeB also
 * changes, among other things, the behaviour of the
 * drive's eject input and tray_status output.
 *
 * author: Kevin East (SeventhSon)
 * email: kev@kev.nu
 * web: http://www.kev.nu/360/
 * date: 2nd March 2006
 * platform: Windows
 *
 */

#include "../ata/ata.h"
#include <windows.h>
#include <string.h>
#include <stdio.h>

int hex_atoi(void *dest, char *src, int dest_len)
{
	int src_last, i, j;
	unsigned char val;

	memset(dest, 0, dest_len);

	src_last = strlen(src) - 1;

	for(i = src_last; i >= 0; i--) {
		if(src[i] >= '0' && src[i] <= '9')
			val = src[i] - 0x30;
		else if(src[i] >= 'a' && src[i] <= 'f')
			val = (src[i] - 0x60) + 9;
		else if(src[i] >= 'A' && src[i] <= 'F')
			val = (src[i] - 0x40) + 9;
		else
			return 1; // invalid hex digit

		j = src_last - i;

		if(j & 1)
			val <<= 4;

#ifdef BIG_ENDIAN		
		j = dest_len - ((j >> 1) + 1);
#else
		j >>= 1;
#endif

		if(j >= dest_len || j < 0)
			break;

		((unsigned char *)dest)[j] |= val;
	}
	
	return 0;
}

int main(int argc, char *argv[])
{
	struct ata_info ai;
	unsigned short comm, ctrl;
	unsigned char pio, packet[12]; 

	LoadIODLL();

	if(argc < 3) {
		printf("usage: modeb_win command_base control_base [pio_mode]\n\ncommand_base: base register of ATA command block in hex (e.g. 1F0 or 170)\ncontrol_base: base register of ATA control block in hex (e.g. 3F6 or 376)\npio_mode: 16 or 32 (default: 32)\n\n");
		return 1;
	}

	if(hex_atoi(&comm, argv[1], sizeof(comm))) {
		printf("error: invalid ATA command block base register\n");
		return 1;
	}
	if(hex_atoi(&ctrl, argv[2], sizeof(ctrl))) {
		printf("error: invalid ATA control block base register\n");
		return 1;
	}
	if(argc > 3) {
		pio = atoi(argv[3]);
		if(pio == 16)
			pio = ATA_PIO_16;
		else if(pio == 32)
			pio = ATA_PIO_32;
		else {
			printf("error: invalid PIO mode (valid: 16 or 32)\n");
			return 1;
		}
	}
	else
		pio = ATA_PIO_16;
		

	ata_init_info(&ai, comm, ctrl, pio, ATA_DEFAULT_TIMEOUT);

	memset(packet, 0, sizeof(packet));
	packet[0] = 0xE7; // Hitachi debug command 0xE7
	packet[1] = 0x48; // 'H'
	packet[2] = 0x49; // 'I'
	packet[3] = 0x54; // 'T'
	packet[4] = 0x30;
	packet[5] = 0x90;
	packet[6] = 0x90;
	packet[7] = 0xD0;
	packet[8] = 0x01;
	if(ata_packet(packet, sizeof(packet), ATA_MASTER, ATA_INTR_ON, &ai))
		ata_dump_err(stdout, &ai.err);
	else
		printf("done\n");

	printf("\n");

	return 0;
}
