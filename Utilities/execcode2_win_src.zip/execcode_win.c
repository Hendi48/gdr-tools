/*
 * uploads any given MN103 code to
 * the Hitachi-LG Xbox360 drive and
 * causes the drive to execute it.
 *
 * author: Kevin East (SeventhSon)
 * email: kev@kev.nu
 * web: http://www.kev.nu/360/
 * date: 15th March 2006 (last updated: 4th April 2006)
 * platform: windows 2000/XP
 *
 */

#include <windows.h>
#include <ntddscsi.h>
#include <stdio.h>
#include <string.h>

#define USAGE "usage: execcode_win drive_letter_or_device_number binary_code_file\n\n"

int main(int argc, char *argv[])
{
	HANDLE fd;
	char dev[40];
	SCSI_PASS_THROUGH_DIRECT *sptd;
	unsigned char sptd_sense[sizeof(*sptd) + 18], *sense, param_list[0x10], *buffer;
	DWORD bytes;
	unsigned int i, len, reallen, blocks, blklen, sum;
	FILE *fptr;
	static unsigned char txblk[0x800];

	sptd = (SCSI_PASS_THROUGH_DIRECT *)sptd_sense;
	sense = &sptd_sense[sizeof(*sptd)];	

	if(argc < 3) {
		printf(USAGE);
		return 1;
	}

	if((argv[1][0] >= 'a' && argv[1][0] <= 'z') || (argv[1][0] >= 'A' && argv[1][0] <= 'Z'))
		sprintf(dev, "\\\\.\\%c:", argv[1][0]);
	else
		sprintf(dev, "\\\\.\\PhysicalDrive%u", atoi(argv[1]));


	if((fd = CreateFile(dev, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL)) == INVALID_HANDLE_VALUE) {
		printf("CreateFile() failed %d\n", GetLastError());
		return 1;
	}
	
	if(!(fptr = fopen(argv[2], "rb"))) {
		CloseHandle(fd);
		printf("fopen() failed\n");
		return 1;
	}

	if(fseek(fptr, 0, SEEK_END) == -1) {
		printf("fseek(SEEK_END) failed\n");
		CloseHandle(fd);
		fclose(fptr);
		return 1;
	}
	if((len = ftell(fptr)) == -1) {
		printf("ftell() failed\n");
		CloseHandle(fd);
		fclose(fptr);
		return 1;
	}
	if(fseek(fptr, 0, SEEK_SET) == -1) {
		printf("fseek(SEEK_SET) failed\n");
		CloseHandle(fd);
		fclose(fptr);
		return 1;
	}

	reallen = len;
	len += 2; // for checksum

	if(len & 0x03) // pad to nearest 4 byte boundary
		len += 4 - (len & 0x03);

	if(!(buffer = (unsigned char *)malloc(len))) {
		printf("malloc() failed\n");
		CloseHandle(fd);
		fclose(fptr);
		return 1;
	}

	memset(buffer, 0, len);

	if(fread(buffer, reallen, 1, fptr) < 1)
		printf("fread() failed\n");
	else {
		// Calculate checksum
		for(sum = 0, i = 0; i < reallen; i++)
			sum += buffer[i];
		sum = 0x10000 - (sum & 0x0000FFFF);
		buffer[len - 2] = (unsigned char)(sum & 0x00FF);
		buffer[len - 1] = (unsigned char)((sum & 0xFF00) >> 8);				

		// initiate modeB
		memset(sptd, 0, sizeof(sptd_sense));
		sptd->Cdb[0] = 0xE7;
		sptd->Cdb[1] = 0x48;
		sptd->Cdb[2] = 0x49;
		sptd->Cdb[3] = 0x54;
		sptd->Cdb[4] = 0x30;
		sptd->Cdb[5] = 0x90;
		sptd->Cdb[6] = 0x90;
		sptd->Cdb[7] = 0xD0;
		sptd->Cdb[8] = 0x01;

		sptd->Length = sizeof(SCSI_PASS_THROUGH);
		sptd->CdbLength = 12;
		sptd->SenseInfoLength = 18;
		sptd->DataIn = SCSI_IOCTL_DATA_UNSPECIFIED;
		sptd->TimeOutValue = 15;
		sptd->SenseInfoOffset = sizeof(*sptd);
	
		if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL) || (sense[2] & 0x0F)) {
			printf("DeviceIOControl() failed %d\n", GetLastError());
			printf("failed to initiate modeB (sense: %02X/%02X/%02X)\n", sense[2] & 0x0F, sense[12], sense[13]);
		}
		else {
			// Stop the disc
			memset(sptd, 0, sizeof(sptd_sense));
			sptd->Cdb[0] = 0x1B;
	
			sptd->Length = sizeof(SCSI_PASS_THROUGH);
			sptd->CdbLength = 12;
			sptd->SenseInfoLength = 18;
			sptd->DataIn = SCSI_IOCTL_DATA_UNSPECIFIED;
			sptd->TimeOutValue = 15;
			sptd->SenseInfoOffset = sizeof(*sptd);
			
			if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL) || ((sense[2] & 0x0F) && ((sense[2] & 0x0F) != 2 || sense[12] != 0x3A))) {
				printf("DeviceIOControl() failed %d\n", GetLastError());
				printf("failed to stop the disc (sense: %02X/%02X/%02X)\n", sense[2] & 0x0F, sense[12], sense[13]);
			}
			else {
				// <hack>
				// Clear (59E) bit 3 if it's set (this bit will cause us problems if it's left set)
				memset(sptd, 0, sizeof(sptd_sense));
				sptd->Cdb[0] = 0x55;
		
				sptd->Length = sizeof(SCSI_PASS_THROUGH);
				sptd->CdbLength = 12;
				sptd->SenseInfoLength = 18;
				sptd->DataIn = SCSI_IOCTL_DATA_UNSPECIFIED;
				sptd->TimeOutValue = 15;
				sptd->SenseInfoOffset = sizeof(*sptd);
				
				DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL);
				// </hack>

				// Configure upload (required to upload/execute code)
				memset(sptd, 0, sizeof(sptd_sense));
				sptd->Cdb[0] = 0x55;
				sptd->Cdb[1] = 0x10;
				sptd->Cdb[8] = 0x10;
				sptd->Cdb[11] = 0x01;
						
				memset(param_list, 0, sizeof(param_list));
				param_list[9] = 0x06;
				param_list[10] = 0x48;
				param_list[11] = 0x4C;
				param_list[12] = (unsigned char)((len & 0xFF000000) >> 24);
				param_list[13] = (unsigned char)((len & 0x00FF0000) >> 16);
				param_list[14] = (unsigned char)((len & 0x0000FF00) >> 8);
				param_list[15] = (unsigned char)(len & 0x000000FF);
					
				sptd->Length = sizeof(SCSI_PASS_THROUGH);
				sptd->CdbLength = 12;
				sptd->SenseInfoLength = 18;
				sptd->DataIn = SCSI_IOCTL_DATA_OUT;
				sptd->DataTransferLength = 0x10;
				sptd->TimeOutValue = 15;
				sptd->DataBuffer = param_list;
				sptd->SenseInfoOffset = sizeof(*sptd);
				
				if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL) || (sense[2] & 0x0F)) {
					printf("DeviceIOControl() failed %d\n", GetLastError());
					printf("failed to configure upload (sense: %02X/%02X/%02X)\n", sense[2] & 0x0F, sense[12], sense[13]);
				}
				else {
					// Upload our buffer in ~2K blocks
					blocks = len / 0x7F8;
					if(len % 0x7F8)
						blocks++;
					for(sum = 0, i = 0; i < blocks; i++) {
						if(i != blocks - 1)
							blklen = 0x800;
						else
							blklen = (len % 0x7F8) + 8;
			
						memset(sptd, 0, sizeof(sptd_sense));
						sptd->Cdb[0] = 0x55;
						sptd->Cdb[1] = 0x10;
						sptd->Cdb[7] = (unsigned char)((blklen & 0xFF00) >> 8);
						sptd->Cdb[8] = (unsigned char)(blklen & 0x00FF);
						sptd->Cdb[11] = 0x01;
			
						memset(txblk, 0, sizeof(txblk));
						txblk[4] = 0x48;
						txblk[5] = 0x4C;
	
						memcpy(&txblk[8], &buffer[i * 0x7F8], blklen - 8);
	
						sptd->Length = sizeof(SCSI_PASS_THROUGH);
						sptd->CdbLength = 12;
						sptd->SenseInfoLength = 18;
						sptd->DataIn = SCSI_IOCTL_DATA_OUT;
						sptd->DataTransferLength = blklen;
						sptd->TimeOutValue = 15;
						sptd->DataBuffer = txblk;
						sptd->SenseInfoOffset = sizeof(*sptd);
				
						if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL) || (sense[2] & 0x0F)) {
							printf("DeviceIOControl() failed %d\n", GetLastError());
							printf("failed to upload buffer block %u (sense: %02X/%02X/%02X)\n", i, sense[2] & 0x0F, sense[12], sense[13]);
							CloseHandle(fd);
							fclose(fptr);
							free(buffer);
							return 1;
						}
					}
		
					// Execute code
					memset(sptd, 0, sizeof(sptd_sense));
					sptd->Cdb[0] = 0x55;
					sptd->Cdb[1] = 0x10;
					sptd->Cdb[3] = 0x48;
					sptd->Cdb[4] = 0x4C;
					sptd->Cdb[6] = 0x01;
					sptd->Cdb[11] = 0x01;
		
					sptd->Length = sizeof(SCSI_PASS_THROUGH);
					sptd->CdbLength = 12;
					sptd->SenseInfoLength = 18;
					sptd->DataIn = SCSI_IOCTL_DATA_UNSPECIFIED;
					sptd->TimeOutValue = 15;
					sptd->SenseInfoOffset = sizeof(*sptd);
				
					if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL) || (sense[2] & 0x0F)) {
						printf("DeviceIOControl() failed %d\n", GetLastError());
						printf("failed to execute flasher (sense: %02X/%02X/%02X)\n", sense[2] & 0x0F, sense[12], sense[13]);
					}
					else
						printf("done\n");
				}
			}
		}
	}

	CloseHandle(fd);
	fclose(fptr);
	free(buffer);

	printf("\n");

	return 0;
}
