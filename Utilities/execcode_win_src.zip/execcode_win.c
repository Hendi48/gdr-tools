/*
 * uploads any given MN103 code to
 * the Hitachi-LG Xbox360 drive and
 * causes the drive to execute it.
 *
 * author: Kevin East (SeventhSon)
 * email: kev@kev.nu
 * web: http://www.kev.nu/360/
 * date: 15th March 2006
 * platform: windows 2000/XP
 *
 */

#include <windows.h>
#include <ntddscsi.h>
#include <stdio.h>
#include <string.h>

#define USAGE "usage: execcode_win drive_letter_or_device_number binary_code_file\n\n"

int main(int argc, char *argv[])
{
	HANDLE fd;
	char dev[40];
	SCSI_PASS_THROUGH_DIRECT *sptd;
	unsigned char sptd_sense[sizeof(*sptd) + 18], *sense, param_list[8];
	DWORD bytes;
	unsigned int i, len;
	FILE *fptr;

	sptd = (SCSI_PASS_THROUGH_DIRECT *)sptd_sense;
	sense = &sptd_sense[sizeof(*sptd)];	

	if(argc < 3) {
		printf(USAGE);
		return 1;
	}

	if((argv[1][0] >= 'a' && argv[1][0] <= 'z') || (argv[1][0] >= 'A' && argv[1][0] <= 'Z'))
		sprintf(dev, "\\\\.\\%c:", argv[1][0]);
	else
		sprintf(dev, "\\\\.\\PhysicalDrive%u", atoi(argv[1]));


	if((fd = CreateFile(dev, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL)) == INVALID_HANDLE_VALUE) {
		printf("CreateFile() failed %d\n", GetLastError());
		return 1;
	}
	
	if(!(fptr = fopen(argv[2], "rb"))) {
		CloseHandle(fd);
		printf("fopen() failed\n");
		return 1;
	}

	// initiate modeB
	memset(sptd, 0, sizeof(sptd_sense));
	sptd->Cdb[0] = 0xE7;
	sptd->Cdb[1] = 0x48;
	sptd->Cdb[2] = 0x49;
	sptd->Cdb[3] = 0x54;
	sptd->Cdb[4] = 0x30;
	sptd->Cdb[5] = 0x90;
	sptd->Cdb[6] = 0x90;
	sptd->Cdb[7] = 0xD0;
	sptd->Cdb[8] = 0x01;

	sptd->Length = sizeof(SCSI_PASS_THROUGH);
	sptd->CdbLength = 12;
	sptd->SenseInfoLength = 18;
	sptd->DataIn = SCSI_IOCTL_DATA_UNSPECIFIED;
	sptd->TimeOutValue = 15;
	sptd->SenseInfoOffset = sizeof(*sptd);
	
	if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL)) {
		printf("DeviceIOControl() failed %d\n", GetLastError());
		printf("failed to initiate modeB (sense: %02X/%02X/%02X)\n", sense[2] & 0x0F, sense[12], sense[13]);
	}
	else {
		if(fseek(fptr, 0, SEEK_END) == -1) {
			CloseHandle(fd);
			fclose(fptr);
			perror("fseek");
			return 1;
		}
		if((len = ftell(fptr)) == -1) {
			CloseHandle(fd);
			fclose(fptr);
			perror("ftell");
			return 1;
		}
		if(fseek(fptr, 0, SEEK_SET) == -1) {
			CloseHandle(fd);
			fclose(fptr);
			perror("fseek");
			return 1;
		}
		// upload code a byte at a time using RAM poke command
		for(i = 0; i < len; i++) {
			// Hitachi poke RAM command
			memset(sptd, 0, sizeof(sptd_sense));
			sptd->Cdb[0] = 0xE7;
			sptd->Cdb[1] = 0x48;
			sptd->Cdb[2] = 0x49;
			sptd->Cdb[3] = 0x54;
			sptd->Cdb[4] = 0xCC;
			sptd->Cdb[5] = (unsigned char)getc(fptr);
			sptd->Cdb[8] = (unsigned char)(((0x80000000 + i) & 0xFF000000) >> 24); // address MSB
			sptd->Cdb[9] = (unsigned char)(((0x80000000 + i) & 0x00FF0000) >> 16); // address
			sptd->Cdb[10] = (unsigned char)(((0x80000000 + i) & 0x0000FF00) >> 8); // address
			sptd->Cdb[11] = (unsigned char)((0x80000000 + i) & 0x000000FF); // address LSB

			sptd->Length = sizeof(SCSI_PASS_THROUGH);
			sptd->CdbLength = 12;
			sptd->SenseInfoLength = 18;
			sptd->DataIn = SCSI_IOCTL_DATA_UNSPECIFIED;
			sptd->TimeOutValue = 15;
			sptd->SenseInfoOffset = sizeof(*sptd);
			
			if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL)) {
				printf("DeviceIOControl() failed %d\n", GetLastError());
				printf("Hitachi poke RAM command failed on byte %u (sense: %02X/%02X/%02X)\n", i, sense[2] & 0x0F, sense[12], sense[13]);
				CloseHandle(fd);
				fclose(fptr);
				return 1;
			}
		}

		// set (59E) bit 3 via Mode Select(10)
		memset(sptd, 0, sizeof(sptd_sense));
		sptd->Cdb[0] = 0x55;
		sptd->Cdb[1] = 0x10;
		sptd->Cdb[8] = 0x08;

		memset(param_list, 0, sizeof(param_list));
		param_list[1] = 6;
		
		sptd->Length = sizeof(SCSI_PASS_THROUGH);
		sptd->CdbLength = 12;
		sptd->SenseInfoLength = 18;
		sptd->DataIn = SCSI_IOCTL_DATA_OUT;
		sptd->DataTransferLength = 8;
		sptd->TimeOutValue = 15;
		sptd->DataBuffer = param_list;
		sptd->SenseInfoOffset = sizeof(*sptd);
		
		if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL)) {
			printf("DeviceIOControl() failed %d\n", GetLastError());
			printf("set (59E) bit 3 via Mode Select(10) failed (sense: %02X/%02X/%02X)\n", sense[2] & 0x0F, sense[12], sense[13]);
		}
		else {
			// jump to RAM routine via Mode Select(10)
			memset(sptd, 0, sizeof(sptd_sense));
			sptd->Cdb[0] = 0x55;
			sptd->Cdb[1] = 0x10;
			sptd->Cdb[3] = 0x48; // 'H'
			sptd->Cdb[4] = 0x4C; // 'L'
			sptd->Cdb[8] = 0x08;

			memset(param_list, 0, sizeof(param_list));
			param_list[1] = 6;
			
			sptd->Length = sizeof(SCSI_PASS_THROUGH);
			sptd->CdbLength = 12;
			sptd->SenseInfoLength = 18;
			sptd->DataIn = SCSI_IOCTL_DATA_OUT;
			sptd->DataTransferLength = 8;
			sptd->TimeOutValue = 15;
			sptd->DataBuffer = param_list;
			sptd->SenseInfoOffset = sizeof(*sptd);

			if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL))
				printf("done\n");
			else
//				printf("this shouldn't happen\n");
				printf("done\n"); // quick hack: in windows DeviceIoControl() doesn't fail here as it does in Linux. I can't think why this would be the case. The poke still works, so I just report done.
		}
	}

	CloseHandle(fd);
	fclose(fptr);

	printf("\n");

	return 0;
}
