/*
 * dumps the a given portion of the address space
 * of the MN103 microcontroller within the 
 * Hitachi-LG Xbox 360 DVD drive. Warning: it can
 * take a while to dump a lot of data.
 *
 * example: dump the internal memory mapped
 *          from 0x40000000 to 0x40020000
 *          with the 360 drive set up as E:
 *          to the file image.bin using a
 *			block size of 0x8000.
 *
 * # ./memdump e 8000 4 8000 ./image.bin
 *
 * author: Kevin East (SeventhSon)
 * email: kev@kev.nu
 * web: http://www.kev.nu/360/
 * date: 15th March 2006
 * platform: windows 2000/XP
 *
 */

#include <windows.h>
#include <ntddscsi.h>
#include <stdio.h>
#include <string.h>


int hex_atoi(void *dest, char *src, int dest_len)
{
	int src_last, i, j;
	unsigned char val;
	unsigned short end;

	end = 0x00FF; // endian detection value

	memset(dest, 0, dest_len);

	src_last = strlen(src) - 1;

	for(i = src_last; i >= 0; i--) {
		if(src[i] >= '0' && src[i] <= '9')
			val = src[i] - 0x30;
		else if(src[i] >= 'a' && src[i] <= 'f')
			val = (src[i] - 0x60) + 9;
		else if(src[i] >= 'A' && src[i] <= 'F')
			val = (src[i] - 0x40) + 9;
		else
			return 1; // invalid hex digit

		j = src_last - i;

		if(j & 1)
			val <<= 4;

		if(*((unsigned char *)&end)) // little endian CPU
			j >>= 1;
		else // big endian CPU
			j = dest_len - ((j >> 1) + 1);

		if(j >= dest_len || j < 0)
			break;

		((unsigned char *)dest)[j] |= val;
	}
	
	return 0;
}

int main(int argc, char *argv[])
{
	HANDLE fd;
	char dev[40];
	SCSI_PASS_THROUGH_DIRECT *sptd;
	unsigned char sptd_sense[sizeof(*sptd) + 18], *sense, *data;
	DWORD bytes;
	unsigned int i, block_size, block_off, block_len;
	FILE *fptr;

	sptd = (SCSI_PASS_THROUGH_DIRECT *)sptd_sense;
	sense = &sptd_sense[sizeof(*sptd)];	

	if(argc != 6) {
		printf("usage: memdump drive_letter_or_device_number offset_in_blocks length_in_blocks block_size output_file\n");
		return 1;
	}

	if(hex_atoi(&block_off, argv[2], sizeof(block_off))) {
		printf("invalid offet_in_blocks (hexadecimal digits only)\n");
		return 1;
	}
	if(hex_atoi(&block_len, argv[3], sizeof(block_len))) {
		printf("invalid length_in_blocks (hexadecimal digits only)\n");
		return 1;
	}
	if(hex_atoi(&block_size, argv[4], sizeof(block_size))) {
		printf("invalid block_size (hexadecimal digits only)\n");
		return 1;
	}
	if(!block_size || block_size > 65535) {
		printf("invalid block_size (valid: 1 - 65535)\n");
		return 1;
	}
	
 	if(!(data = malloc(block_size + 1))) { // quick hack: + 1 (see comment below)
		printf("malloc() failed\n");
		return 1;
	}

	if((argv[1][0] >= 'a' && argv[1][0] <= 'z') || (argv[1][0] >= 'A' && argv[1][0] <= 'Z'))
		sprintf(dev, "\\\\.\\%c:", argv[1][0]);
	else
		sprintf(dev, "\\\\.\\PhysicalDrive%u", atoi(argv[1]));

	if((fd = CreateFile(dev, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL)) == INVALID_HANDLE_VALUE) {
		free(data);
		printf("CreateFile() failed %d\n", GetLastError());
		return 1;
	}

	if(!(fptr = fopen(argv[5], "wb"))) {
		free(data);
		CloseHandle(fd);
		printf("fopen failed\n");
		return 1;
	}
	
	for(i = block_off; i < block_off + block_len; i++) {
		memset(data, '0', sizeof(data));
		memset(sptd, 0, sizeof(sptd_sense));
		sptd->Cdb[0] = 0xE7; // vendor specific command (discovered by DaveX)
		sptd->Cdb[1] = 0x48; // H
		sptd->Cdb[2] = 0x49; // I
		sptd->Cdb[3] = 0x54; // T
		sptd->Cdb[4] = 0x01; // read MCU memory sub-command
		sptd->Cdb[6] = (unsigned char)(((i * block_size) & 0xFF000000) >> 24); // address MSB
		sptd->Cdb[7] = (unsigned char)(((i * block_size) & 0x00FF0000) >> 16); // address
		sptd->Cdb[8] = (unsigned char)(((i * block_size) & 0x0000FF00) >> 8); // address
		sptd->Cdb[9] = (unsigned char)((i * block_size) & 0x000000FF); // address LSB
		sptd->Cdb[10] = (unsigned char)((block_size & 0xFF00) >> 8); // length MSB
		sptd->Cdb[11] = (unsigned char)(block_size & 0x00FF); // length LSB

		sptd->Length = sizeof(SCSI_PASS_THROUGH);
		sptd->CdbLength = 12;
		sptd->SenseInfoLength = 18;
		sptd->DataIn = SCSI_IOCTL_DATA_IN;
		// quick hack: windows hates sptd->DataTransferLength = 1, so we set it to 2 and ignore the second byte.
		if(block_size == 1)
			sptd->DataTransferLength = 2;
		else
			sptd->DataTransferLength = block_size;
		sptd->TimeOutValue = 15;
		sptd->DataBuffer = data;
		sptd->SenseInfoOffset = sizeof(*sptd);

		if(!DeviceIoControl(fd, IOCTL_SCSI_PASS_THROUGH_DIRECT, sptd, sizeof(*sptd) + 18, sptd, sizeof(*sptd) + 18, &bytes, NULL)) {
			printf("DeviceIOControl() failed %d\n", GetLastError());
			printf("sense: %02X/%02X/%02X (offset 0x%08X)\n", sense[2] & 0x0F, sense[12], sense[13], i * block_size);
		}
		else {
			fwrite(data, block_size, 1, fptr);
			if(ferror(fptr))
				printf("fwrite() failed (offset 0x%08X)\n", i * block_size);
		}
	}
	
	printf("\n");

	free(data);
	fclose(fptr);
	CloseHandle(fd);

	return 0;
}
